function [Bmag] = ReadFromMagnetometer(mag)

fprintf(mag,'*00P');
Braw = fscanf(mag);
i = 1;

while Braw(i) == ' '
    i = i+1;
end

if Braw(i) == '-'
    while Braw(i+1) == ' '
        Braw(i+1) = '-';
        Braw(i) = ' ';
        i = i + 1;
    end
end

while Braw(i) ~= ' '  
    if Braw(i) == ','
       for j = 1:4
          Braw(i) = Braw(i+1);
          i = i + 1;
       end
    else
        i = i+1;
    end
end

while Braw(i) == ' '
    i = i+1;
end

if Braw(i) == '-'
    while Braw(i+1) == ' '
        Braw(i+1) = '-';
        Braw(i) = ' ';
        i = i + 1;
    end
end

while Braw(i) ~= ' '
     if Braw(i) == ','
       for j = 1:4
          Braw(i) = Braw(i+1);
          i = i + 1;
       end
    else
        i = i+1;
    end
end

while Braw(i) == ' '
    i = i+1;
end

if Braw(i) == '-'
    while Braw(i+1) == ' '
        Braw(i+1) = '-';
        Braw(i) = ' ';
        i = i + 1;
    end
end

while Braw(i) ~= ' '
     if Braw(i) == ','
       for j = 1:4
          Braw(i) = Braw(i+1);
          i = i + 1;
       end
    else
        i = i+1;
    end
end

Bmag = str2num(Braw)/15000