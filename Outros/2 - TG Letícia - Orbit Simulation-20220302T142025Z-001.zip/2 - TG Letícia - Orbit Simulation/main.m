clear all
close all
clc
%% Initialize Magnetometer HMR2300
% mag = serial('COM6'); % Define COM port
% fopen(mag);
% mag.Terminator = 'CR';
% fprintf(mag, '*00WE');
% fscanf(mag);
% fprintf(mag, '*00A');
% fscanf(mag);

%% Initialize SPG4 with TLE

min_per_day = 60*24;
TLE = ('TLEUS6.txt'); % TLESCD1.txt
tle = fopen(TLE, 'r');
tle = fscanf(tle, '%69c%69c');
longstr1 = tle(1:69);
longstr2 = tle(72:139);
satrec = twoline2rvMOD(longstr1,longstr2);

fprintf('\n')
fprintf('Satellite ID %5i \n', satrec.satnum)

%% Simulation time parameters definition

dt = 200; % time step - [s]
hours = 1.5; % hours of simulation
L = hours*3600/dt; % number of simulation intervals
tsince = [0:L - 1]*dt/60; % array of time instants used in the simulation

%% Print satellite information

if (satrec.epochyr < 57)
    Eyear = satrec.epochyr + 2000;
else   
    Eyear = satrec.epochyr + 1900;   
end

[Emon, Eday, Ehr, Emin, Esec] = days2mdh(Eyear, satrec.epochdays);

UTsec = Ehr*3600 + Emin*60 + Esec;
timehack = [Eyear, Emon, Eday, Ehr, Emin, Esec];
GAST = siderealtime(timehack, 0);
gst = gstime(satrec.jdsatepoch);
fprintf(' YEAR MO  DAY UTSEC \n')
fprintf('%5i %2i %4i %5.2f gst=%6.4f rad \n', Eyear, Emon, Eday, UTsec, gst);
fprintf('\n Time step for simulation: %d s', dt)
fprintf('\n Hours of simulation: %4f h', hours)

%% Variables initialization

gst = zeros(1, L);
xsat_eci = zeros(3, L);
vsat_eci = zeros(3, L);
xsat_ecf = zeros(3, L);
vsat_ecf = zeros(3, L);
q_ref = zeros(4, L);
w_ref = zeros(3, L);
euler_ref = zeros(3, L);
perm = 1.2566e-6; % Magnetic permeability in vacuum - [T.m/A]
N = 40; % Number of coil turns      
% Half the length of one side of each coil (L/2) - [m]
a_x = 1.2235; 
a_y = 1.25;
a_z = 1.197;
% Ratio between the distance between the coils and 2a to optimize
% field's uniformity at the cage's center
gama = 0.5445; 
B_theo = zeros(L, 2)
Bx_theo = zeros(L, 2)
By_theo = zeros(L, 2)
Bz_theo = zeros(L, 2)

%% Orbit propagation and simulation in Helmholtz cage

fprintf('\n --- Instrument connection --- \n')
% Creates GPIB object associated to a Agilent instrument and connects with instrument

% Supply B
gb = gpib('agilent',7,5); % Board index first and, then, primary address
fopen(gb);
gb.EOSMode = 'read&write';
gb.EOSCharCode = 'LF'

% Supply A
ga = visa('agilent', 'GPIB1::5::INSTR');
fopen(ga); 
ga.EOSMode = 'read&write';
ga.EOSCharCode = 'LF'

% Supply C
gc = visa('agilent', 'GPIB2::5::INSTR');
fopen(gc);
gc.EOSMode = 'read&write';
gc.EOSCharCode = 'LF'

fprintf('\n\n --- Orbit propagation and simulation --- \n')
for n = 1:L
    
    % Orbit propagation
    [satrec, xsat_eci(:, n), vsat_eci(:, n)] = sgp4(satrec, tsince(n));
    
    % Compute Greenwich Apparent Siderial Time
    gst(n) = gstime(satrec.jdsatepoch + tsince(n)/min_per_day);
    
    % Convert position vector from ECI to ECEF axes
    CGAST = cos(gst(n));
    SGAST = sin(gst(n));
    xsat_ecf(1, n) = xsat_eci(1, n)*CGAST + xsat_eci(2, n)*SGAST;
    xsat_ecf(2, n) = -xsat_eci(1, n)*SGAST + xsat_eci(2, n)*CGAST;
    xsat_ecf(3, n) = xsat_eci(3, n);
    
    % Convert velocity vector from ECI to ECEF axes
    OMEGAE = 7.29211586D-5; % Earth rotation rate - [rad/s]
    vsat_ecf(1, n) = vsat_eci(1, n)*CGAST + vsat_eci(2, n)*SGAST + OMEGAE*xsat_ecf(2, n);
    vsat_ecf(2, n) = -vsat_eci(1, n)*SGAST + vsat_eci(2, n)*CGAST - OMEGAE*xsat_ecf(1, n);
    vsat_ecf(3, n) = vsat_eci(3, n);
        
    LLA = ecef2lla([xsat_ecf(1, n), xsat_ecf(2, n), xsat_ecf(3, n)]);
    
    lat(n) = LLA(1);
    long(n) = LLA(2);
    alt(n) = LLA(3);
    height(n) = abs(LLA(3)+6371000);
    
    % Alternative way to calculate lat and long
    % radius(n) = mag(xsat_eci(:, n));
    % velocity(n) = mag(vsat_eci(:, n));
    % lat(n) = asin(xsat_ecf(3, n)/radius(n))*180/pi;
    % long(n) = atan2(xsat_ecf(2, n),xsat_ecf(3, n))*180/pi;

    % Calculate earth's magnetic field at each time step on July 4, 2010,
    % using WMM-2015 - [T]
    [xyz, h, dec, dip, f] = wrldmagm(height(n), lat(n), long(n), decyear(2017,7,6),'2015');
    Bx = xyz(1)*1e-9;
    By = xyz(2)*1e-9;
    Bz = xyz(3)*1e-9;
    B = norm(xyz)*1e-9;
    fprintf('\n Bx = %f T | By = %f T | Bz = %f T | B modulus = %f T', Bx, By, Bz, B)
    
    % Convert magnetic field from [T] to [G]
    Bx_gauss = Bx*1e4;
    By_gauss = By*1e4;
    Bz_gauss = Bz*1e4;
    B_gauss = norm([Bx_gauss By_gauss Bz_gauss]);
    fprintf('\n Bx = %f G | By = %f G | Bz = %f G | B modulus = %f G', Bx_gauss, By_gauss, Bz_gauss, B_gauss)
    
    Bx_theo(n, 1) = Bx_gauss;
    Bx_theo(n, 2) = n;
    By_theo(n, 1) = By_gauss;
    By_theo(n, 2) = n;
    Bz_theo(n, 1) = Bz_gauss;
    Bz_theo(n, 2) = n;
    B_theo(n, 1) = B_gauss;
    B_theo(n, 2) = n;
    
    % Calculate current and voltage that will generate each component of
    % the magnetic field in the Helmholtz cage using theorical model
%     Ix = (abs(Bx)*pi*a_x*(1+gama^2)*sqrt(2+gama^2))/(4*perm*N);
%     Vx = VoltageCalculationX(Ix);
%     Iy = (abs(By)*pi*a_y*(1+gama^2)*sqrt(2+gama^2))/(4*perm*N);
%     Vy = VoltageCalculationY(Iy);
%     Iz = (abs(Bz)*pi*a_z*(1+gama^2)*sqrt(2+gama^2))/(4*perm*N);
%     Vz = VoltageCalculationZ(Iz);

    % Calculate voltage with equations from initial calibration results 
    Vx = (abs(Bx_gauss) - 0.004)/0.0415
    Vy = (abs(By_gauss) - 0.0046)/0.0374
    Vz = (abs(Bz_gauss) - 0.0046)/0.0379
    
    %% With negative field components supported
%     Ix = (Bx*pi*a_x*(1+gama^2)*sqrt(2+gama^2))/(4*perm*N);
%     Vx = VoltageCalculationX(abs(Ix));
%     Iy = (By*pi*a_y*(1+gama^2)*sqrt(2+gama^2))/(4*perm*N);
%     Vy = VoltageCalculationY(abs(Iy));
%     Iz = (Bz*pi*a_z*(1+gama^2)*sqrt(2+gama^2))/(4*perm*N);
%     Vz = VoltageCalculationZ(abs(Iz));
% Or
%     Vx = (Bx_gauss - 0.004)/0.0415
%     Vy = (By_gauss - 0.0046)/0.0374
%     Vz = (Bz_gauss - 0.0046)/0.0379 
%       
%     a = arduino();
%     a = arduino('COM', 'uno'); % Set COM port
%
%     if Vx < 0
%         writeDigitalPin(a, 'D7', 1);
%     else
%         writeDigitalPin(a, 'D7', 0);
%     end
%     
%     if Vy < 0 
%         writeDigitalPin(a, 'D6', 0);
%     else
%         writeDigitalPin(a, 'D7', 1);
%     end
%     
%     if Vz < 0 
%         writeDigitalPin(a, 'D5', 0);
%     else
%         writeDigitalPin(a, 'D7', 1);
%     end
   
    %% Send commands to supply to generate field
    SendCommandsToSupply(ga, gb, gc, Vx, Vy, Vz);
    %Bmag = ReadFromMagnetometer(mag);
    fprintf('\n\n Simulation interval %d \n Latitude: %f �\n Longitude: %f � \n Height: %f m', n, lat(n), long(n), height(n))
    pause(10); % <= 3s
end
SendCommandsToSupply(ga, gb, gc, 0, 0, 0);
CloseInstrumentConnection(ga, gb, gc);
figures