function[v] = VoltageCalculationX(i)

v = (i - 0.0156)/0.1522;