function [ga, gb, gc] = InstrumentConnection()
 % Supply A = Y axis
 % Supply B = Z axis 
 % Supply C = X axis
%% Creates GPIB object associated to a Agilent instrument and connects with instrument

% Supply B
gb = gpib('agilent',7,5) % Board index first and, then, primary address
fopen(gb)
gb.EOSMode = 'read&write'
gb.EOSCharCode = 'LF'

% Supply A
ga = visa('agilent', 'GPIB1::5::INSTR')
fopen(ga) 
ga.EOSMode = 'read&write'
ga.EOSCharCode = 'LF'

% Supply C
gc = visa('agilent', 'GPIB2::5::INSTR')
fopen(gc)
gc.EOSMode = 'read&write'
gc.EOSCharCode = 'LF'

fprintf('\n --- Fim Instrument connection --- \n')