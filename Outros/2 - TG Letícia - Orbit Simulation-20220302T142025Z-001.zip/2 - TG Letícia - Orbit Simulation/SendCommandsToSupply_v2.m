function SendCommandsToSupply_v2(ga, gb, gc, Vx, Vy, Vz)
%% Updates (Rodrigo, Jo�o, Lucas):
% Feb 16th 2018: code optimized (function only sets output voltage)

%% Observation
% Supply A = Y axis
% Supply B = Z axis 
% Supply C = X axis

% Output voltage
output = sprintf('VSET %d', Vy);
fprintf(ga,output);
output = sprintf('VSET %d', Vx);
fprintf(gc,output);
output = sprintf('VOLT %d', Vz);
fprintf(gb,output);
