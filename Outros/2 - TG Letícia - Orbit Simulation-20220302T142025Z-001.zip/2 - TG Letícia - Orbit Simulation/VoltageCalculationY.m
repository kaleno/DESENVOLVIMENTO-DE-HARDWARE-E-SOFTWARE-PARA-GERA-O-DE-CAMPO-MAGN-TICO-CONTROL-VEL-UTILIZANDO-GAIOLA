function[v] = VoltageCalculationY(i)

v = (i - 0.0133)/0.1449;