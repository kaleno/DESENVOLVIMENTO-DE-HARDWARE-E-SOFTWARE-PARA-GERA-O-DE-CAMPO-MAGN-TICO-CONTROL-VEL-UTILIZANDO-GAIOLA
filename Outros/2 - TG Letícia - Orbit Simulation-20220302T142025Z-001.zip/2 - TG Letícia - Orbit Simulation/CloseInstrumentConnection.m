function CloseInstrumentConnection(ga, gb, gc)
%% Close connection and erase GPIB object

% Supply A
fclose(ga); 
delete(ga); 
clear ga;

%Supply B
fclose(gb); 
delete(gb); 
clear gb;

%Supply C
fclose(gc); 
delete(gc); 
clear gc;