function SendCommandsToSupply(ga, gb, gc, Vx, Vy, Vz)

 % Supply A = Y axis
 % Supply B = Z axis 
 % Supply C = X axis

%% Sending SCPI or COMP commands to the power supplies
% Supply A (COMP)
fprintf(ga,'ERR?');
errA = fscanf(ga);
fprintf(ga,'ID?');
idSupplyA = fscanf(ga);
fprintf(ga,'VOUT?');
vSupplyA = fscanf(ga)
fprintf(ga,'IOUT?');
iSupplyA = fscanf(ga);
fprintf(ga,'ISET 6'); % Current limit value

% Supply B (SCPI)
fprintf(gb,'*IDN?');
idSupplyB = fscanf(gb)
fprintf(gb,'VOLT?');
vSupplyB = fscanf(gb);
fprintf(gb,'MEAS:CURR?');
iSupplyB = fscanf(gb);

% Supply C (COMP)
fprintf(gb,'CURR 6'); % Current limit value
fprintf(gc,'ERR?');
errC = fscanf(gc);
fprintf(gc,'ID?');
idSupplyC = fscanf(gc)
fprintf(gc,'VOUT?');
vSupplyC = fscanf(gc)
fprintf(gc,'IOUT?');
iSupplyC = fscanf(gc);
fprintf(gc,'ISET 6'); % Current limit value

% Output voltage
output = sprintf('VSET %d', Vy);
fprintf(ga,output);
output = sprintf('VSET %d', Vx);
fprintf(gc,output);
output = sprintf('VOLT %d', Vz);
fprintf(gb,output);
