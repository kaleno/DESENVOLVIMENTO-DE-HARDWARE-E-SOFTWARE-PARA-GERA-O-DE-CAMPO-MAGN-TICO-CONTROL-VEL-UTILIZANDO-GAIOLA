close all

%% Earth plot
space_color = 'k';
npanels = 36;   % Number of globe panels around the equator deg/panel = 360/npanels
alpha = 0.95; % globe transparency level, 1 = opaque, through 0 = invisible

% Earth texture image
% Anything imread() will handle), but needs to be a 2:1 unprojected globe
% image.
% This is from NASA's Visible Earth site (http://visibleearth.nasa.gov/)
% The actual image link will likely move over time. This one is the 260KB
% version from this page: http://visibleearth.nasa.gov/view_rec.php?id=2430

image_file = 'BlueMarble.png';%'http://eoimages.gsfc.nasa.gov/ve/2430/land_ocean_ice_2048.jpg';

% Mean spherical earth

erad = 6371.0087714; % equatorial radius (meters)
prad = 6371.0087714; % polar radius (meters)
erot = 7.2921158553e-5; % earth rotation rate (radians/sec)

% Create figure

figure('Color', space_color);
hold on;

% Turn off the normal axes
set(gca, 'NextPlot','add', 'Visible','off');

axis equal;
axis auto;
axis vis3d;
view(100,30);

%% Create wireframe globe

% Create a 3D meshgrid of the sphere points using the ellipsoid function

[x, y, z] = ellipsoid(0, 0, 0, erad, erad, prad, npanels);
globe = surf(x, y, -z, 'FaceColor', 'none', 'EdgeColor', 0.5*[1 1 1]);

%% Texturemap the globe

% Load Earth image for texture map

cdata = imread(image_file);

% Set image as color data (cdata) property, and set face color to indicate
% a texturemap, which Matlab expects to be in cdata. Turn off the mesh edges.
plot3(x, y, z, 'c-.', 'LineWidth', 0.0000000001)
set(globe, 'FaceColor', 'texturemap', 'CData', cdata, 'FaceAlpha', alpha, 'EdgeColor', 'none');
hold on
plot3(xsat_eci(1, :), xsat_eci(2, :), xsat_eci(3, :));
plot3(xsat_eci(1, 1), xsat_eci(2, 1), xsat_eci(3, 1), 'y', 'Linewidth', 5);

%% Magnetic field plots (theorical)

% B modulus vs Time step of simulation
figure
plot(B_theo(:,2), B_theo(:,1), 'o')
title('Magnetic Field to be simulated')
xlabel('Time step (s)')
ylabel('|B| (G)')

% B modulus vs Time step of simulation (read from fixed magnetometer)

