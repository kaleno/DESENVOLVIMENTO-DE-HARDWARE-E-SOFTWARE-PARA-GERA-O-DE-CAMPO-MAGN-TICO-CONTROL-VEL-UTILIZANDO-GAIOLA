function[v] = VoltageCalculationZ(i)

v = (i - 0.0077)/0.1460;